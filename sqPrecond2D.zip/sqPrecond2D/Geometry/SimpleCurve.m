classdef SimpleCurve
    % Parametric curve, can be closed but must not intersect itself
    
    properties
        x; % Function of 1 argument (the parameter t)
        y; %
        I; % interval of the values for the parameter t
        closed@logical;
        boundedSide;
        dx;
        dy;
    end
    
    methods
        function[this] = SimpleCurve(xx,yy,II,bS)
            this.x = xx;
            this.y = yy;
            this.I = II;
            a = II(1); b = II(2); Ma = [xx(a);yy(a)]; Mb = [xx(b);yy(b)];
            this.closed = norm(Ma-Mb)<1e-11;
            if this.closed
                assert(logical(exist('bS','var')),'this curve is closed. You must pass the boundedSide (value "left" or "right") in argument');
                assert(ismember(bS,{'left','right'}),['This curve is closed. the value used for argument bS is incorrect. Please use one of the choices : "left" or "right". \n' ...
                     'choose left if the bounded component of the plane lies at the left of the curve, and right otherwise.'])
                this.boundedSide = bS;
            else
                this.boundedSide = 'none';
            end
            this.dx = @(t)(1e6*(this.x(t + 1e-6) - this.x(t)));
            this.dy = @(t)(1e6*(this.y(t + 1e-6) - this.y(t)));
        end
        function[newC] = reparametrize(this,c,d)
            a = this.I(1); b = this.I(2);
            
            newC = this;
            newC.I = [c,d];
            
            
        end
        function[c] = portion(this,aa,bb)
            c = this;
            c.I(1) = aa;
            c.I(2) = bb;
        end
        function[] = plot(this,varargin)
            N = 100;
            II = this.I;
            t = this.s_1(linspace(0,this.length()-0.00001,1000));
            xt = this.x(t);
            yt = this.y(t);
            plot(xt,yt,varargin{:});
            t = this.s_1(linspace(0,this.length()-0.00001,100));
            hold on;
            plot(this.x(t),this.y(t),'*');
            axis equal
        end
        function[Gs] = s(this,t)
            t_size = size(t);
            t = [this.I(1);t(:)];
            [xx,ww] = Gauss_Legendre1D(5,0,1);
            X = t(1:(end-1))*ones(1,length(xx)) + diff(t)*xx';
            W = diff(t)*ww';
            F = @(u)(sqrt(this.dx(u).^2 + this.dy(u).^2));
            Gs = F(X).*W;
            Gs = sum(Gs,2);
            Gs = cumsum(reshape(Gs,t_size(1),t_size(2)));
        end
        function[r] = length(this)
            r = integral(@(t)(sqrt(this.dx(t).^2 + this.dy(t).^2)),this.I(1),this.I(2));
        end
        function[t] = s_1(this,S)
            F = @(u)(sqrt(this.dx(u).^2 + this.dy(u).^2));
            size_s = size(S);
            S = S(:);
            tGuess = linspace(this.I(1),this.I(2),length(S));
            tGuess = tGuess(:);
            sGuess = s(this,tGuess);
            err = norm(sGuess - S,'inf');
            while err > 1e-8
                tGuess = tGuess + (S - sGuess)./F(tGuess);
                sGuess =  s(this,tGuess);
                err = norm(sGuess - S,2);
            end
            t = tGuess;
            t = reshape(t(:),size_s(1),size_s(2));
        end
        function[s] = rep_s(w)
            % Looks for s such that int_[s_i,s_{i+1}] w = cte
            
        end
%         function[t] = s_1(this,s)
%             [~,Idx] = sort(s);
%             t = zeros(size(s));
%             t0 = -1;
%             for i = 1:length(Idx)
%                 t(Idx(i)) = fzero(@(t)(this.s(t) - s(Idx(i))),t0);
%                 t0 = t(Idx(i));
%             end
%         end
    end
end

