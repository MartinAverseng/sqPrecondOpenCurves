function [arc,incWave ,dxf,dyf] = spirale(k)

a=  1*4/4.8098/1.4261;
b= 0.2;
c= 2;
s0 = -0.5;
x = @(s)(a*exp(b*c*(s+s0)).*cos(c*(s+s0)));
y = @(s)(a*exp(b*c*(s+s0)).*sin(c*(s+s0)));
I = [-1,1];
arc = SimpleCurve(x,y,I);
arc.dx = @(s)(a*c*exp(b*c*(s0 + s)).*(b*cos(c*(s0 + s)) - sin(c*(s0 + s))));
arc.dy = @(s)(a*c*exp(b*c*(s0 + s)).*(b*sin(c*(s0 + s)) + cos(c*(s0 + s))));


if and(nargout >= 2,nargin ==1)
    theta_inc = pi/4 - pi/2;
    X = R2toRfunc.X; Y = R2toRfunc.Y;
    incWave = exp(1i*k*(X*cos(theta_inc) + Y*sin(theta_inc)));
    dxf = 1i*k*cos(theta_inc)*incWave;% = d(incwave)/dx
    dyf = 1i*k*sin(theta_inc)*incWave;
end

if nargin == 0
    close all
    plot(arc)
%     disp(length(arc))
end


end



