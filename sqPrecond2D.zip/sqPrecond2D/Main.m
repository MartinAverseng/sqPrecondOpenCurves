clc
clear all
close all
disp('Clearing vars')
addpath(genpath(pwd));
