%% Test case on some shape with edges.


Main;
nn = 20;
curve = spirale;
l = length(curve);
k = nn*pi/l;
[curve,incWave,dxf,dyf] = unitSegment(k);
disp("k = ")
disp(k);
% plot(curve);
N = fix(10*k);
disp("Assembling FE spaces")
meshAdapt = MeshCurve(curve,N,@cos,[-pi,0]);
Vh =  weightedFEspace(meshAdapt,'P1','1/sqrt(1-t^2)',...
    'quadNum',3,'specialQuadSegs',1:meshAdapt.nseg);

Wh =  weightedFEspace(meshAdapt,'P1','sqrt(1-t^2)',3,'specialQuadSegs',1:meshAdapt.nseg);
M = Wh.Mass.concretePart;
[L,U,P,Q] = lu(M);
invM = @(u)(Q*(U\(L \(P*u))));

disp("Assembling N")
Op_opt = {'tol',1e-3,'a_factor',3};
Nw = hyperSingular_w(Vh,'k',k,'Op_opt',Op_opt);
Nwgalerk = Nw.galerkine;

disp("Assembling rhs")
secondMemb = Wh.normalDerivative(dxf,dyf);

disp("Assembling square-root preconditioner")
t2 = tic;
dM = (Vh.omega_dx_omega)'*AbstractMatrix.spdiag(Vh.W)*(Vh.omega_dx_omega);
dM = dM.concretePart;   
omega2 = Wh.omega2;
K1 = dM - k^2*(omega2-M);
K = dM - k^2*omega2;
Np = 15;
theta = pi/3;
keps = k+1i*0.01*k^(1/3);
sqrtDarbasK1 = @(x)(padePrecondDarbas(x,Np,theta,keps,M,K1));
clear dM;
clear omega2;
PrecDarbas = @(u)(K\sqrtDarbasK1(invM(u)));
t2 = toc(t2);
disp("Time Assembling (s)")
disp(t2);

disp("Solving with Sq-root prec")
t1 = tic;
[lambda1,FLAG1,RELRES1,ITER1,RESVEC1] = variationalSol(Nwgalerk,secondMemb,[],1e-8,N,PrecDarbas);
t1 = toc(t1);
disp("Time Solving(s)")
disp(t1);
disp("Nit")
disp(length(RESVEC1));


disp("Assembling Calderon prec")
t4 = tic;
Sw = singleLayer(Vh,...
    'Op_opt',Op_opt,'correcMethod','constantTerm','k',k);
Swgalerk = Sw.galerkine(Vh,'U');
SS = AbstractMatrix(Swgalerk);

PrecCald = @(u)(Vh.Mass.concretePart\(SS*(invM(u))));
t4 = toc(t4);
disp("Time assemlbing (s)")
disp(t4);

clear M L U Q P dM K K1 omega2 

disp("Solving with Calderon Prec")
t0 = tic;
[lambda0,FLAG0,RELRES0,ITER0,RESVEC0] = variationalSol(Nwgalerk,secondMemb,[],1e-8,N,PrecCald);
t0 = toc(t0);
disp("Time(s)")
disp(t0)
disp("Nit")
disp(length(RESVEC0));


figure
semilogy(1:length(RESVEC0),RESVEC0/norm(PrecCald(secondMemb.concretePart)),'-o');
hold on
semilogy(1:length(RESVEC1),RESVEC1/norm(PrecDarbas(secondMemb.concretePart)),'--x');


xlabel('Iteration number')
ylabel('Residual error')

legend({'Calderon','Square root'});
legend boxoff
