%% Test case on some shape with edges.


Main;
nn = 100;
curve = unitSegment();
l = length(curve);
k = nn*pi/l;
[curve,incWave] = unitSegment(k);
disp("k = ")
disp(k);

plot(curve);
N = fix(10*k);
disp("Creating mesh")
meshAdapt = MeshCurve(curve,N,@cos,[-pi,0]); 

disp("Creating FE spaces")
Vh =  weightedFEspace(meshAdapt,'P1','1/sqrt(1-t^2)',...
    'quadNum',3,'specialQuadSegs',1:meshAdapt.nseg);
M = Vh.Mass.concretePart;
[L,U,P,Q] = lu(M);
invM = @(u)(Q*(U\(L \(P*u))));

Wh =  weightedFEspace(meshAdapt,'P1','sqrt(1-t^2)',3);


Op_opt = {'tol',1e-3,'a_factor',3};
disp("Assembling S")
Sw = singleLayer(Vh,...
    'Op_opt',Op_opt,'correcMethod','constantTerm','k',k);

Swgalerk = Sw.galerkine(Vh,'U');

disp("Assembling rhs")
secondMemb = Vh.secondMember(-incWave);

disp("Assembling Square-root precondtioner")
t3 = tic;
dM =  Wh.dMass.concretePart;
omega2 = Wh.Mass.concretePart;

K1 = dM - k^2*(omega2 -M);
Np = 15;
theta = pi/3;
keps = k+1i*0.025*k^(1/3);
sqrtDarbasK1 = @(x)(padePrecondDarbas(x,Np,theta,keps,M,K1));

PrecDarbas = @(u)(invM(sqrtDarbasK1(invM(u))));
t3 = toc(t3);
disp("Time assembling sq (s)")
disp(t3);

clear M L U Q P dM K K1 


disp("Solving with square-root preconditioner")
t1 = tic;
[lambda1,FLAG1,RELRES1,ITER1,RESVEC1] = variationalSol(Swgalerk,secondMemb,[],1e-8,N,PrecDarbas);
t1 = toc(t1);
disp("Time solve (s):")
disp(t1);
disp("Nit: ")
disp(length(RESVEC1));


disp("Assembling Calderon Prec")
t2 = tic;
Nw = hyperSingular_w(Vh,'k',k,'Op_opt',Op_opt);
Nwgalerk = Nw.galerkine;
NN = AbstractMatrix(Nwgalerk);

PrecCald = @(u)(omega2\(NN*invM(u)));
t2 = toc(t2);
disp("Time assemble Calderon (s)")
disp(t2);



disp("Solving with calderon preconditioner")
t0 = tic;
[lambda0,FLAG0,RELRES0,ITER0,RESVEC0] = variationalSol(Swgalerk,secondMemb,[],1e-8,N,PrecCald);
t0 = toc(t0);
disp("Time solve Calderon (s):")
disp(t0)
disp("Nit: ")
disp(length(RESVEC0));




figure
semilogy(1:length(RESVEC0),RESVEC0/norm(PrecCald(secondMemb.concretePart)),'-o');
hold on
semilogy(1:length(RESVEC1),RESVEC1/norm(PrecDarbas(secondMemb.concretePart)),'--x');


xlabel('Iteration number')
ylabel('Residual error')

legend({'Calderon preconditioner','Square root preconditioner'});
legend boxoff

