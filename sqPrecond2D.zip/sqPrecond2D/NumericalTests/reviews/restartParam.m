%% Influence of the restart parameter:


Main;
nn = 10;
restarts = {[],5,10,20,40};
ITER = {};
RESVEC = {};
figure;
for i = 1:length(restarts)
    restart = restarts{i};
    curve = unitSegment;
    l = length(curve);
    k = nn*pi/l;
    [curve,incWave] = unitSegment(k);
    
    
    N = fix(10*k);
    meshAdapt = MeshCurve(curve,N,@cos,[-pi,0]);
    Vh =  weightedFEspace(meshAdapt,'P1','1/sqrt(1-t^2)',...
        'quadNum',3,'specialQuadSegs',1:meshAdapt.nseg);
    M = Vh.Mass.concretePart;
    [L,U,P,Q] = lu(M);
    invM = @(u)(Q*(U\(L \(P*u))));
    Wh =  weightedFEspace(meshAdapt,'P1','sqrt(1-t^2)',3);
    
    dM =  Wh.dMass.concretePart;
    omega2 = Wh.Mass.concretePart;
    
    K1 = dM - k^2*(omega2 -M);
    K2 = dM;
    Np = 15;
    theta = pi/3;
    keps = k+1i*0.025*k^(1/3);
    sqrtDarbasK1 = @(x)(padePrecondDarbas(x,Np,theta,keps,M,K1));
    sqrtDarbasK2 = @(x)(padePrecondDarbas(x,Np,theta,keps,M,K2));
    
    
    Op_opt = {'tol',1e-4,'a_factor',5};
    Sw = singleLayer(Vh,...
        'Op_opt',Op_opt,'correcMethod','constantTerm','k',k);
    
    Swgalerk = Sw.galerkine(Vh,'U');
    
    PrecDarbas = @(u)(invM(sqrtDarbasK1(invM(u))));
    PrecDarbas2 = @(u)(invM(sqrtDarbasK2(invM(u))));
    T0_scal_phi = Vh.phi'*Vh.W;
    T0_star_galerk = T0_scal_phi*T0_scal_phi'/sum(Vh.W);
    
    PrecTref = @(u)(invM(TrefethenSqrt(dM,6,invM(u),M,1.5,2*Vh.ndof^2)) + (1/log(2))^2*invM(T0_star_galerk*invM(u)));
    
    
    % clear M L U Q P dM K K1 omega2
    
    secondMemb = Vh.secondMember(-incWave);
    [lambda0,FLAG0,RELRES,ITER{i},RESVEC{i}] = variationalSol(Swgalerk,secondMemb,restart,...
        1e-8,size(Swgalerk,1));
    
    if isempty(restart)
        name = 'no restart';
    else
        name = sprintf('Restart = %s',num2str(restart));
    end
    semilogy(1:length(RESVEC{i}),RESVEC{i}/norm(secondMemb.concretePart),'-s','LineWidth',1,'MarkerSize',10,...
        'DisplayName',name);
    
    hold on
    
    
    
    
end
set(gca,'Fontsize',30);
legend show
legend boxoff


xlabel('Iteration number')
ylabel('Residual error')
%
